fx_version 'cerulean'
game 'gta5'

name 'WordBomber'
version '1.0.0'
author 'Isaiah'
description 'FiveM Chat Protection!'

client_script 'src/client/client.js'
server_script 'src/server/server.js'
